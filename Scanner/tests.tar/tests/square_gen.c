
#include <stdio.h>

#define read(x) scanf("%d",&x)

#define write(x) printf("%d\n",x)

#define print(x) printf(x)

int cs512square(int cs512x)
{
    int cs512x;
    cs512x = 10;

    return cs512x * cs512x;
}

int main(void)
{
    int cs512val;
    print("Give me a number: ");
    read(cs512val);

    print("Your number squared is: ");
    write(cs512square(cs512val));
}
