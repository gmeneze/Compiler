
#include <stdio.h>

#define read(x) scanf("%d",&x)

#define write(x) printf("%d\n",x)

#define print(x) printf(x)

void cs512bar
!!ERROR!!
 <@> could not be classified as a valid token 
the input program is illegal
